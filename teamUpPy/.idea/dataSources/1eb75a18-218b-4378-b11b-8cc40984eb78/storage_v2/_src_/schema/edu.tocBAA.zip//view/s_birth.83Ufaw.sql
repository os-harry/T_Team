create view s_birth as
  select `edu`.`student`.`SNO` AS `SNO`, `edu`.`student`.`SNAME` AS `SNAME`, (2018 - `edu`.`student`.`SAGE`) AS `SBIRTH`
  from `edu`.`student`;

