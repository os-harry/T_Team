create view zgy_courses as
  select `edu`.`course`.`CNO`     AS `CNO`,
         `edu`.`course`.`CNAME`   AS `CNAME`,
         `edu`.`course`.`CPNO`    AS `CPNO`,
         `edu`.`course`.`CCREDIT` AS `CCREDIT`
  from `edu`.`student`
         join `edu`.`sc`
         join `edu`.`course`
  where ((`edu`.`student`.`SNAME` = '赵古韵') and (`edu`.`student`.`SNO` = `edu`.`sc`.`SNO`) and
         (`edu`.`sc`.`CNO` = `edu`.`course`.`CNO`));

